# REVAvis
Visualization Software for REVAvis

## Install dependencies
``` install.packages(c("shiny", "waiter", "ggplot2", "dplyr")) ```

## Install REVAvis
Clone REVAvis from GitHub:
https://github.com/mjmccoy/REVAvis.git

Alternatively, download REVAvis:
https://github.com/mjmccoy/REVAvis/archive/master.zip
